"""
=====================
Spatial graph example
=====================

A short description of what the example does.
"""

import knotpy as kp
from knotpy.generate.example import example_spatial_graph

g = example_spatial_graph()
print(g)