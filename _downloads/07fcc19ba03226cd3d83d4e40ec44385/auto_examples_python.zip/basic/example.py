"""
=====================
Spatial graph example
=====================

A short description of what the example does.
"""

import knotpy as kp

k = kp.PlanarDiagram()
print(k)
