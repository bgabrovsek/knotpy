from knotpy import kauffman_bracket_skein_module

raw = """
a=V(b3) b=X(c3 c2 d0 a0) c=X(e0 d1 b1 b0) d=X(b2 c1 f3 e1) e=X(c0 d3 g3 f0) f=X(e3 g2 h0 d2) g=X(i3 i2 f1 e2) h=X(f2 i1 j0 i0) i=X(h3 h1 g1 g0) j=V(h2)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e0 f0 b1 b0) d=X(b2 f3 g0 e1) e=X(c0 d3 h0 i3) f=X(c1 i2 g1 d1) g=X(d2 f2 i1 h1) h=X(e2 g3 i0 j0) i=X(h2 g2 f1 e3) j=V(h3)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 e0 d1) d=X(b2 c3 f0 e1) e=X(c2 d3 g3 f1) f=X(d2 e3 g2 h0) g=X(h3 i0 f2 e2) h=X(f3 i3 i1 g0) i=X(g1 h2 j0 h1) j=V(i2)
a=V(b3) b=X(c3 d0 d3 a0) c=X(e3 f0 g3 b0) d=X(b1 g2 e0 b2) e=X(d2 h3 f1 c0) f=X(c1 e2 h2 i0) g=X(i3 h0 d1 c2) h=X(g1 i2 f2 e1) i=X(f3 j0 h1 g0) j=V(i1)
a=V(b0) b=X(a0 c3 d3 c0) c=X(b3 e0 f0 b1) d=X(f3 g0 h3 b2) e=V(c1) f=X(c2 i0 g1 d0) g=X(d1 f2 i3 h0) h=X(g3 j0 j3 d2) i=X(f1 j2 j1 g2) j=X(h1 i2 i1 h2)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e0 f0 b1 b0) d=X(b2 e3 g0 h3) e=X(c0 h2 g1 d1) f=V(c1) g=X(d2 e2 i3 i2) h=X(i1 i0 e1 d3) i=X(h1 h0 g3 g2)
a=V(b0) b=X(a0 c3 d3 d2) c=X(e3 f0 g3 b1) d=X(h3 h2 b3 b2) e=X(h1 i0 f1 c0) f=X(c1 e2 i3 g0) g=X(f3 i1 h0 c2) h=X(g2 e0 d1 d0) i=X(e1 g1 j0 f2) j=V(i2)
a=V(b3) b=X(c0 d0 c1 a0) c=X(b0 b2 e3 d1) d=X(b1 c3 e2 f3) e=X(g3 f0 d2 c2) f=X(e1 h0 g0 d3) g=X(f2 i0 h1 e0) h=X(f1 g2 i3 i2) i=X(g1 j0 h3 h2) j=V(i1)
a=V(b3) b=X(c0 d0 d3 a0) c=X(b0 e0 f3 g0) d=X(b1 g3 h0 b2) e=X(c1 h3 i3 f0) f=X(e3 i2 j0 c2) g=X(c3 i1 h1 d1) h=X(d2 g2 i0 e1) i=X(h2 g1 f1 e2) j=V(f2)
a=V(b3) b=X(c3 d3 c0 a0) c=X(b2 e0 d0 b0) d=X(c2 e3 f3 b1) e=X(c1 g3 f0 d1) f=X(e2 h0 g0 d2) g=X(f2 i0 i3 e1) h=X(f1 i2 j0 i1) i=X(g1 h3 h1 g2) j=V(h2)
a=V(b3) b=X(c0 d0 c1 a0) c=X(b0 b2 e3 d1) d=X(b1 c3 f0 g3) e=X(g2 h3 i3 c2) f=X(d2 i2 h1 g0) g=X(f3 h0 e0 d3) h=X(g1 f2 i0 e1) i=X(h2 j0 f1 e2) j=V(i1)
a=V(b0) b=X(a0 c3 d0 c0) c=X(b3 e0 e3 b1) d=X(b2 f0 g3 e1) e=X(c1 d3 f1 c2) f=X(d1 e2 g2 h3) g=X(i3 i2 f2 d2) h=X(i1 j0 i0 f3) i=X(h2 h0 g1 g0) j=V(h1)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 e3 e1 b2) d=X(f3 g0 e0 b3) e=X(d2 c2 h0 c1) f=X(i3 i2 g1 d0) g=X(d1 f2 i1 i0) h=V(e2) i=X(g3 g2 f1 f0)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 e0 f0) d=X(b2 g0 h3 f1) e=V(c2) f=X(c3 d3 h2 g1) g=X(d1 f3 i3 i2) h=X(i1 i0 f2 d2) i=X(h1 h0 g3 g2)
a=V(b3) b=X(c0 d3 c1 a0) c=X(b0 b2 e3 f0) d=X(g3 h0 e0 b1) e=X(d2 h3 f1 c2) f=X(c3 e2 i0 g0) g=X(f3 i3 h1 d0) h=X(d1 g2 i2 e1) i=X(f2 j0 h2 g1) j=V(i1)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 e3 f3 b2) d=X(f2 g0 g3 b3) e=X(h0 g2 f0 c1) f=X(e2 g1 d0 c2) g=X(d1 f1 e1 d2) h=V(e0)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e0 d1 b1 b0) d=X(b2 c1 f3 e1) e=X(c0 d3 f2 g0) f=X(g3 h3 e2 d2) g=X(e3 h2 h0 f0) h=X(g2 i0 g1 f1) i=V(h1)
a=V(b3) b=X(c3 d0 c0 a0) c=X(b2 e3 d1 b0) d=X(b1 c2 f0 e0) e=X(d3 g0 f1 c1) f=X(d2 e2 g3 h3) g=X(e1 h2 h0 f2) h=X(g2 i0 g1 f3) i=V(h1)
a=V(b3) b=X(c3 c2 d0 a0) c=X(d3 e0 b1 b0) d=X(b2 f3 g3 c0) e=V(c1) f=X(h3 i0 g0 d1) g=X(f2 i3 h0 d2) h=X(g2 j0 j3 f0) i=X(f1 j2 j1 g1) j=X(h1 i2 i1 h2)
a=V(b0) b=X(a0 c0 d3 d2) c=X(b1 d1 e3 f3) d=X(e0 c1 b3 b2) e=X(d0 g0 f0 c2) f=X(e2 h3 g1 c3) g=X(e1 f2 i3 i2) h=X(i1 i0 j0 f1) i=X(h1 h0 g3 g2) j=V(h2)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 e0 d0 b2) d=X(c2 e3 f0 b3) e=X(c1 g3 f1 d1) f=X(d2 e2 h3 h2) g=X(i3 j0 i2 e1) h=X(i1 i0 f3 f2) i=X(h1 h0 g2 g0) j=V(g1)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e0 d1 b2) d=X(b3 c2 e3 f0) e=X(c1 g3 f1 d2) f=X(d3 e2 g2 h3) g=X(h1 h0 f2 e1) h=X(g1 g0 i0 f3) i=V(h2)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e3 d1 b2) d=X(b3 c2 f3 e0) e=X(d3 f2 g3 c1) f=X(h3 g0 e1 d2) g=X(f1 h2 i0 e2) h=X(i3 i2 g1 f0) i=X(g2 j0 h1 h0) j=V(i1)
a=V(b0) b=X(a0 c0 d3 d2) c=X(b1 e0 f3 d0) d=X(c3 e1 b3 b2) e=X(c1 d1 f2 g0) f=X(g3 h0 e2 c2) g=X(e3 i0 h1 f0) h=X(f1 g2 i3 i2) i=X(g1 j0 h3 h2) j=V(i1)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e3 e2 b1 b0) d=X(b2 f0 g0 h0) e=X(h3 f1 c1 c0) f=X(d1 e1 i3 g1) g=X(d2 f3 i2 h1) h=X(d3 g3 i0 e0) i=X(h2 j0 g2 f2) j=V(i1)
a=V(b0) b=X(a0 c0 c2 d3) c=X(b1 e0 b2 f0) d=X(e3 g0 h0 b3) e=X(c1 h3 i3 d0) f=V(c3) g=X(d1 j0 j3 h1) h=X(d2 g3 i0 e1) i=X(h2 j2 j1 e2) j=X(g1 i2 i1 g2)
a=V(b3) b=X(c0 c2 d0 a0) c=X(b0 e0 b1 f0) d=X(b2 g0 h0 e1) e=X(c1 d3 i3 g1) f=V(c3) g=X(d1 e3 j0 h1) h=X(d2 g3 j3 i0) i=X(h3 j2 j1 e2) j=X(g2 i2 i1 h2)
a=V(b0) b=X(a0 c0 d3 e0) c=X(b1 e3 f3 g0) d=X(g3 f1 e1 b2) e=X(b3 d2 f0 c1) f=X(e2 d1 g2 c2) g=X(c3 h0 f2 d0) h=V(g1)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e0 d1 b2) d=X(b3 c2 f0 e1) e=X(c1 d3 f3 g0) f=X(d2 g3 h0 e2) g=X(e3 h3 h1 f1) h=X(f2 g2 i0 g1) i=V(h2)
a=V(b3) b=X(c0 d0 d3 a0) c=X(b0 e0 f3 g3) d=X(b1 g2 h0 b2) e=X(c1 h3 i0 f0) f=X(e3 h2 g0 c2) g=X(f2 h1 d1 c3) h=X(d2 g1 f1 e1) i=V(e2)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 d3 e3) d=X(b2 e2 f0 c2) e=X(g3 f1 d1 c3) f=X(d2 e1 g2 h0) g=X(i3 i2 f2 e0) h=X(f3 j0 i1 i0) i=X(h3 h2 g1 g0) j=V(h1)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 d3 e3 b2) d=X(b3 f0 e0 c1) e=X(d2 f3 g0 c2) f=X(d1 h0 g1 e1) g=X(e2 f2 i0 h1) h=X(f1 g3 i3 i2) i=X(g2 j0 h3 h2) j=V(i1)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e3 d1 b2) d=X(b3 c2 f0 g0) e=X(g3 h0 i3 c1) f=X(d2 i2 h2 g1) g=X(d3 f3 h1 e0) h=X(e1 g2 f2 i1) i=X(j0 h3 f1 e2) j=V(i0)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e3 d1 b2) d=X(b3 c2 f0 g3) e=X(g2 h3 i0 c1) f=X(d2 i3 h1 g0) g=X(f3 h0 e0 d3) h=X(g1 f2 i1 e1) i=X(e2 h2 j0 f1) j=V(i2)
a=V(b0) b=X(a0 c3 d3 c0) c=X(b3 e0 d2 b1) d=X(f3 g3 c2 b2) e=V(c1) f=X(g2 h0 i3 d0) g=X(i2 h1 f0 d1) h=X(f1 g1 i1 i0) i=X(h3 h2 g0 f2)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 d3 e0) d=X(b2 f3 g0 c2) e=V(c3) f=X(g3 h3 i0 d1) g=X(d2 i3 h0 f0) h=X(g2 j0 j3 f1) i=X(f2 j2 j1 g1) j=X(h1 i2 i1 h2)
a=V(b0) b=X(a0 c0 d3 d2) c=X(b1 e3 f3 g0) d=X(g3 g2 b3 b2) e=X(f2 h3 i0 c1) f=X(i3 h0 e0 c2) g=X(c3 j0 d1 d0) h=X(f1 i2 i1 e1) i=X(e2 h2 h1 f0) j=V(g1)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 e0 f0) d=X(b2 f3 g3 h3) e=V(c2) f=X(c3 h2 i0 d1) g=X(i3 j0 j3 d2) h=X(j2 i1 f1 d3) i=X(f2 h1 j1 g0) j=X(g1 i2 h0 g2)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e0 f0 b2) d=X(b3 e3 g0 h3) e=X(c1 i3 g1 d1) f=V(c2) g=X(d2 e2 i2 j0) h=X(j3 j2 i0 d3) i=X(h2 j1 g2 e1) j=X(g3 i1 h1 h0)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 e0 f3) d=X(b2 g3 h3 e1) e=X(c2 d3 i3 f0) f=X(e3 i2 g0 c3) g=X(f2 i1 h1 d1) h=X(j0 g2 i0 d2) i=X(h2 g1 f1 e2) j=V(h0)
a=V(b3) b=X(c3 d0 c0 a0) c=X(b2 d3 e3 b0) d=X(b1 e2 f3 c1) e=X(g3 f0 d1 c2) f=X(e1 g2 h0 d2) g=X(i3 i2 f1 e0) h=X(f2 j0 i1 i0) i=X(h3 h2 g1 g0) j=V(h1)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 e3 d0 b2) d=X(c2 f0 e0 b3) e=X(d2 g0 f1 c1) f=X(d1 e2 g3 h0) g=X(e1 h3 h1 f2) h=X(f3 g2 i0 g1) i=V(h2)
a=V(b3) b=X(c3 d0 d3 a0) c=X(e0 f3 g0 b0) d=X(b1 h0 e1 b2) e=X(c0 d2 g3 f0) f=X(e3 i0 i3 c1) g=X(c2 i2 i1 e2) h=V(d1) i=X(f1 g2 g1 f2)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 d1 e0 b2) d=X(b3 c1 f0 g3) e=V(c2) f=X(d2 h3 i0 g0) g=X(f3 i3 h0 d3) h=X(g2 i2 i1 f1) i=X(f2 h2 h1 g1)
a=V(b3) b=X(c3 d0 c0 a0) c=X(b2 e3 f3 b0) d=X(b1 g0 h3 e0) e=X(d3 h2 f0 c1) f=X(e2 i3 g1 c2) g=X(d1 f2 i2 h0) h=X(g3 i0 e1 d2) i=X(h1 j0 g2 f1) j=V(i1)
a=V(b0) b=X(a0 c0 d3 d2) c=X(b1 e3 f3 g0) d=X(g3 e0 b3 b2) e=X(d1 h0 f0 c1) f=X(e2 i0 g1 c2) g=X(c3 f2 h1 d0) h=X(e1 g2 i3 i2) i=X(f1 j0 h3 h2) j=V(i1)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e3 d1 b2) d=X(b3 c2 e2 f0) e=X(f3 g3 d2 c1) f=X(d3 h0 h3 e0) g=X(i0 h2 h1 e1) h=X(f1 g2 g1 f2) i=V(g0)
a=V(b3) b=X(c3 d3 c0 a0) c=X(b2 e3 d0 b0) d=X(c2 e2 f0 b1) e=X(f3 g0 d1 c1) f=X(d2 g3 h0 e0) g=X(e1 i0 i3 f1) h=X(f2 i2 j0 i1) i=X(g1 h3 h1 g2) j=V(h2)
a=V(b0) b=X(a0 c3 d3 d2) c=X(e0 f3 d0 b1) d=X(c2 f2 b3 b2) e=X(c0 g3 h3 f0) f=X(e3 g0 d1 c1) g=X(f1 h2 h0 e1) h=X(g2 i0 g1 e2) i=V(h1)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 e0 d0 b2) d=X(c2 f3 e1 b3) e=X(c1 d2 g3 g2) f=X(g1 h0 g0 d1) g=X(f2 f0 e3 e2) h=V(f1)
a=V(b0) b=X(a0 c0 c2 d3) c=X(b1 d2 b2 e0) d=X(f0 g0 c1 b3) e=V(c3) f=X(d0 g3 h0 i3) g=X(d1 i2 h1 f1) h=X(f2 g2 j3 j2) i=X(j1 j0 g1 f3) j=X(i1 i0 h3 h2)
a=V(b3) b=X(c3 c2 d3 a0) c=X(d2 e3 b1 b0) d=X(f3 g0 c0 b2) e=X(g3 h0 f0 c1) f=X(e2 h3 i0 d0) g=X(d1 i3 h1 e0) h=X(e1 g2 i1 f1) i=X(f2 h2 j0 g1) j=V(i2)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 e3 d1) d=X(b2 c3 e2 f0) e=X(f3 g3 d2 c2) f=X(d3 h0 g0 e0) g=X(f2 i0 i3 e1) h=X(f1 i2 i1 j0) i=X(g1 h2 h1 g2) j=V(h3)
a=V(b3) b=X(c3 d0 d3 a0) c=X(d2 e0 f3 b0) d=X(b1 e1 c0 b2) e=X(c1 d1 g0 f0) f=X(e3 h3 g1 c2) g=X(e2 f2 i3 i2) h=X(i1 i0 j0 f1) i=X(h1 h0 g3 g2) j=V(h2)
a=V(b0) b=X(a0 c0 d3 e3) c=X(b1 e2 f0 g0) d=X(f3 f2 e0 b2) e=X(d2 f1 c1 b3) f=X(c2 e1 d1 d0) g=V(c3)
a=V(b0) b=X(a0 c0 c2 d3) c=X(b1 d2 b2 e0) d=X(f0 g3 c1 b3) e=V(c3) f=X(d0 g2 h0 i3) g=X(i2 h1 f1 d1) h=X(f2 g1 i1 i0) i=X(h3 h2 g0 f3)
a=V(b0) b=X(a0 c3 d0 c0) c=X(b3 d2 d1 b1) d=X(b2 c2 c1 e3) e=X(f3 f2 g3 d3) f=X(h3 h2 e1 e0) g=X(i3 j0 i2 e2) h=X(i1 i0 f1 f0) i=X(h1 h0 g2 g0) j=V(g1)
a=V(b3) b=X(c0 d0 d3 a0) c=X(b0 d2 e0 f3) d=X(b1 e1 c1 b2) e=X(c2 d1 g0 f0) f=X(e3 h0 h3 c3) g=X(e2 i0 j0 i3) h=X(f1 i2 i1 f2) i=X(g1 h2 h1 g3) j=V(g2)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e3 e2 b1 b0) d=X(b2 f3 g0 h3) e=X(i3 i2 c1 c0) f=X(h1 g2 g1 d1) g=X(d2 f2 f1 h0) h=X(g3 f0 i0 d3) i=X(h2 j0 e1 e0) j=V(i1)
a=V(b0) b=X(a0 c3 d0 c0) c=X(b3 e0 e3 b1) d=X(b2 e2 e1 f0) e=X(c1 d2 d1 c2) f=V(d3)
a=V(b3) b=X(c0 d0 c1 a0) c=X(b0 b2 e0 d1) d=X(b1 c3 e3 f3) e=X(c2 f2 g3 d2) f=X(h0 g0 e1 d3) g=X(f1 i0 i3 e2) h=X(f0 i2 i1 j0) i=X(g1 h2 h1 g2) j=V(h3)
a=V(b3) b=X(c3 c2 d3 a0) c=X(e0 f3 b1 b0) d=X(f2 g3 e1 b2) e=X(c0 d2 h3 i3) f=X(i2 g0 d0 c1) g=X(f1 i1 h1 d1) h=X(j0 g2 i0 e2) i=X(h2 g1 f0 e3) j=V(h0)
a=V(b0) b=X(a0 c3 d0 c0) c=X(b3 e3 f0 b1) d=X(b2 g3 h3 e0) e=X(d3 h2 f1 c1) f=X(c2 e2 h1 i0) g=X(i3 j0 i2 d1) h=X(i1 f2 e1 d2) i=X(f3 h0 g2 g0) j=V(g1)
a=V(b3) b=X(c0 c2 d0 a0) c=X(b0 e0 b1 f0) d=X(b2 g3 h3 e1) e=X(c1 d3 i0 g0) f=V(c3) g=X(e3 j3 h0 d1) h=X(g2 j2 i1 d2) i=X(e2 h2 j1 j0) j=X(i3 i2 h1 g1)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 d3 e0 b2) d=X(b3 f0 g3 c1) e=V(c2) f=X(d1 h3 i0 g0) g=X(f3 i3 h0 d2) h=X(g2 j0 j3 f1) i=X(f2 j2 j1 g1) j=X(h1 i2 i1 h2)
a=V(b0) b=X(a0 c3 d0 c0) c=X(b3 e0 f3 b1) d=X(b2 g0 h0 e1) e=X(c1 d3 h3 f0) f=X(e3 h2 i0 c2) g=X(d1 i3 i1 h1) h=X(d2 g3 f1 e2) i=X(f2 g2 j0 g1) j=V(i2)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 e0 d0 b2) d=X(c2 e3 f3 b3) e=X(c1 g3 f0 d1) f=X(e2 h0 g0 d2) g=X(f2 i0 i3 e1) h=X(f1 i2 j0 i1) i=X(g1 h3 h1 g2) j=V(h2)
a=V(b0) b=X(a0 c0 c2 d0) c=X(b1 d3 b2 e0) d=X(b3 f3 g3 c1) e=V(c3) f=X(h3 i0 g0 d1) g=X(f2 i3 h0 d2) h=X(g2 i2 i1 f0) i=X(f1 h2 h1 g1)
a=V(b3) b=X(c0 d0 c1 a0) c=X(b0 b2 e3 d1) d=X(b1 c3 e2 f0) e=X(f3 g0 d2 c2) f=X(d3 g3 h3 e0) g=X(e1 i0 i3 f1) h=X(i2 j0 i1 f2) i=X(g1 h2 h0 g2) j=V(h1)
a=V(b0) b=X(a0 c3 d3 d2) c=X(e0 f3 g3 b1) d=X(g2 e1 b3 b2) e=X(c0 d1 h0 f0) f=X(e3 h3 g0 c1) g=X(f2 i0 d0 c2) h=X(e2 i2 i1 f1) i=X(g1 h2 h1 j0) j=V(i3)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e3 e2 b1 b0) d=X(b2 f0 g0 h3) e=X(h2 f1 c1 c0) f=X(d1 e1 i0 g1) g=X(d2 f3 i3 h0) h=X(g3 i1 e0 d3) i=X(f2 h1 j0 g2) j=V(i2)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 d1 e0) d=X(b2 c2 f0 g0) e=V(c3) f=X(d2 h0 i3 g1) g=X(d3 f3 i2 h1) h=X(f1 g3 i1 i0) i=X(h3 h2 g2 f2)
a=V(b3) b=X(c3 d3 c0 a0) c=X(b2 e3 d0 b0) d=X(c2 f3 e0 b1) e=X(d2 g0 g3 c1) f=X(h0 i0 i3 d1) g=X(e1 i2 i1 e2) h=V(f0) i=X(f1 g2 g1 f2)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 d3 e3) d=X(b2 e2 f3 c2) e=X(f2 g3 d1 c3) f=X(g2 h0 e0 d2) g=X(h3 h2 f0 e1) h=X(f1 i0 g1 g0) i=V(h1)
a=V(b0) b=X(a0 c3 d3 d2) c=X(e3 f0 g0 b1) d=X(g3 h0 b3 b2) e=X(h3 i0 f1 c0) f=X(c1 e2 i3 g1) g=X(c2 f3 h1 d0) h=X(d1 g2 i2 e0) i=X(e1 j0 h2 f2) j=V(i1)
a=V(b3) b=X(c0 d0 d3 a0) c=X(b0 e3 f3 g0) d=X(b1 g3 e0 b2) e=X(d2 h3 f0 c1) f=X(e2 h2 i3 c2) g=X(c3 i2 h0 d1) h=X(g2 i1 f1 e1) i=X(j0 h1 g1 f2) j=V(i0)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 d2 e3 b2) d=X(e2 f3 c1 b3) e=X(g0 f0 d0 c2) f=X(e1 g3 h3 d1) g=X(e0 h2 h0 f1) h=X(g2 i0 g1 f2) i=V(h1)
a=V(b3) b=X(c0 d0 c1 a0) c=X(b0 b2 d3 e0) d=X(b1 f0 g0 c2) e=X(c3 g3 h3 f1) f=X(d1 e3 h2 i0) g=X(d2 i3 h0 e1) h=X(g2 i1 f2 e2) i=X(f3 h1 j0 g1) j=V(i2)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e3 d1 b1 b0) d=X(b2 c1 f3 g3) e=X(g2 h3 i0 c0) f=X(i3 h1 g0 d2) g=X(f2 h0 e0 d3) h=X(g1 f1 i1 e1) i=X(e2 h2 j0 f0) j=V(i2)
a=V(b3) b=X(c0 d3 c1 a0) c=X(b0 b2 e0 f3) d=X(g0 h0 e1 b1) e=X(c2 d2 h3 f0) f=X(e3 i3 g1 c3) g=X(d0 f2 i2 h1) h=X(d1 g3 i1 e2) i=X(j0 h2 g2 f1) j=V(i0)
a=V(b0) b=X(a0 c0 d0 d2) c=X(b1 e3 f3 d1) d=X(b2 c3 b3 g0) e=X(f2 h0 i3 c1) f=X(i2 h1 e0 c2) g=V(d3) h=X(e1 f1 i1 i0) i=X(h3 h2 f0 e2)
a=V(b0) b=X(a0 c3 d3 d2) c=X(e3 f3 d0 b1) d=X(c2 e0 b3 b2) e=X(d1 f2 g3 c0) f=X(g2 h3 e1 c1) g=X(i3 h0 f0 e2) h=X(g1 i2 i0 f1) i=X(h2 j0 h1 g0) j=V(i1)
a=V(b0) b=X(a0 c3 c1 d0) c=X(e0 b2 f0 b1) d=X(b3 g0 h0 e1) e=X(c0 d3 i0 g1) f=V(c2) g=X(d1 e3 j3 h1) h=X(d2 g3 j2 i1) i=X(e2 h3 j1 j0) j=X(i3 i2 h2 g2)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e0 d1 b2) d=X(b3 c2 f3 e1) e=X(c1 d3 f2 g0) f=X(h3 g1 e2 d2) g=X(e3 f1 h2 i0) h=X(i3 i1 g2 f0) i=X(g3 h1 j0 h0) j=V(i2)
a=V(b3) b=X(c0 d0 c1 a0) c=X(b0 b2 e3 d1) d=X(b1 c3 e2 f0) e=X(f3 g0 d2 c2) f=X(d3 h0 g1 e0) g=X(e1 f2 h3 i3) h=X(f1 i2 i0 g2) i=X(h2 j0 h1 g3) j=V(i1)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 e3 d0 b2) d=X(c2 f3 e0 b3) e=X(d2 g3 f0 c1) f=X(e2 g2 h3 d1) g=X(h2 i3 f1 e1) h=X(i1 i0 g0 f2) i=X(h1 h0 j0 g1) j=V(i2)
a=V(b0) b=X(a0 c0 d3 c1) c=X(b1 b3 e3 d0) d=X(c3 f3 e0 b2) e=X(d2 f2 g3 c2) f=X(h3 g0 e1 d1) g=X(f1 i0 h0 e2) h=X(g2 i3 i1 f0) i=X(g1 h2 j0 h1) j=V(i2)
a=V(b0) b=X(a0 c0 d0 c1) c=X(b1 b3 e3 f0) d=X(b2 g3 h0 e0) e=X(d3 h3 g0 c2) f=V(c3) g=X(e2 i0 i3 d1) h=X(d2 j0 j3 e1) i=X(g1 j2 j1 g2) j=X(h1 i2 i1 h2)
a=V(b3) b=X(c0 d3 c1 a0) c=X(b0 b2 e3 e2) d=X(f3 g0 h0 b1) e=X(i3 f0 c3 c2) f=X(e1 i2 g1 d0) g=X(d1 f2 i1 h1) h=X(d2 g3 j0 i0) i=X(h3 g2 f1 e0) j=V(h2)
a=V(b3) b=X(c0 d0 c1 a0) c=X(b0 b2 e0 d1) d=X(b1 c3 e3 f3) e=X(c2 f2 g0 d2) f=X(g3 h0 e1 d3) g=X(e2 h3 i3 f0) h=X(f1 i2 i0 g1) i=X(h2 j0 h1 g2) j=V(i1)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e0 e3 b2) d=X(b3 f0 g3 h3) e=X(c1 i0 i2 c2) f=X(d1 h1 g1 g0) g=X(f3 f2 h0 d2) h=X(g2 f1 i1 d3) i=X(e1 h2 e2 j0) j=V(i3)
a=V(b0) b=X(a0 c0 d3 d2) c=X(b1 e0 f0 d0) d=X(c3 e1 b3 b2) e=X(c1 d1 f3 g0) f=X(c2 g3 h0 e2) g=X(e3 h3 h1 f1) h=X(f2 g2 i0 g1) i=V(h2)
a=V(b3) b=X(c3 d0 d3 a0) c=X(e0 f3 g0 b0) d=X(b1 g3 h3 b2) e=X(c0 h2 i0 f0) f=X(e3 i3 j0 c1) g=X(c2 i2 h0 d1) h=X(g2 i1 e1 d2) i=X(e2 h1 g1 f1) j=V(f2)
a=V(b0) b=X(a0 c0 d3 d2) c=X(b1 e0 f0 g0) d=X(g3 e1 b3 b2) e=X(c1 d1 h3 f1) f=X(c2 e3 h2 i3) g=X(c3 i2 h0 d0) h=X(g2 i1 f2 e2) i=X(j0 h1 g1 f3) j=V(i0)
a=V(b0) b=X(a0 c3 d3 c0) c=X(b3 e3 f0 b1) d=X(g3 h0 e0 b2) e=X(d2 h3 f1 c1) f=X(c2 e2 h2 g0) g=X(f3 i0 h1 d0) h=X(d1 g2 f2 e1) i=V(g1)
a=V(b3) b=X(c0 d0 d3 a0) c=X(b0 e0 f0 d1) d=X(b1 c3 e1 b2) e=X(c1 d2 f3 g0) f=X(c2 g3 h0 e2) g=X(e3 h3 i0 f1) h=X(f2 i2 i1 g1) i=X(g2 h2 h1 j0) j=V(i3)
a=V(b0) b=X(a0 c3 d3 d2) c=X(e0 f3 g0 b1) d=X(g3 g2 b3 b2) e=X(c0 h0 i3 f0) f=X(e3 i2 h1 c1) g=X(c2 j0 d1 d0) h=X(e1 f2 i1 i0) i=X(h3 h2 f1 e2) j=V(g1)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e3 e2 b1 b0) d=X(b2 f0 g3 g2) e=X(h3 h2 c1 c0) f=V(d1) g=X(i3 i2 d3 d2) h=X(j3 j2 e1 e0) i=X(j1 j0 g1 g0) j=X(i1 i0 h1 h0)
a=V(b3) b=X(c3 d0 d3 a0) c=X(d2 e0 f0 b0) d=X(b1 e1 c0 b2) e=X(c1 d1 g3 f1) f=X(c2 e3 h3 g0) g=X(f3 i3 h0 e2) h=X(g2 i2 i0 f2) i=X(h2 j0 h1 g1) j=V(i1)
a=V(b0) b=X(a0 c0 c3 d0) c=X(b1 e0 e3 b2) d=X(b3 f3 g0 h3) e=X(c1 i0 i2 c2) f=X(i1 h2 g1 d1) g=X(d2 f2 h1 h0) h=X(g3 g2 f1 d3) i=X(e1 f0 e2 j0) j=V(i3)
a=V(b0) b=X(a0 c0 d3 c1) c=X(b1 b3 d2 e0) d=X(e3 f0 c2 b2) e=X(c3 f3 g3 d0) f=X(d1 g2 h0 e1) g=X(h3 h2 f1 e2) h=X(f2 i0 g1 g0) i=V(h1)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e3 d1 b1 b0) d=X(b2 c1 e2 f0) e=X(f3 g3 d2 c0) f=X(d3 h0 h3 e0) g=X(i0 h2 h1 e1) h=X(f1 g2 g1 f2) i=V(g0)
a=V(b0) b=X(a0 c3 d3 c0) c=X(b3 d2 e3 b1) d=X(f3 e0 c1 b2) e=X(d1 f2 g3 c2) f=X(g2 h0 e1 d0) g=X(h3 h2 f0 e2) h=X(f1 i0 g1 g0) i=V(h1)
a=V(b0) b=X(a0 c0 d3 c1) c=X(b1 b3 e0 d0) d=X(c3 e3 f0 b2) e=X(c2 g0 f1 d1) f=X(d2 e2 h3 g1) g=X(e1 f3 i0 h0) h=X(g3 i2 i1 f2) i=X(g2 h2 h1 j0) j=V(i3)
a=V(b0) b=X(a0 c0 d3 d2) c=X(b1 e3 f0 g0) d=X(g3 e0 b3 b2) e=X(d1 h0 f1 c1) f=X(c2 e2 h3 i0) g=X(c3 i3 h1 d0) h=X(e1 g2 i2 f2) i=X(f3 j0 h2 g1) j=V(i1)
a=V(b0) b=X(a0 c0 d3 c1) c=X(b1 b3 e0 f3) d=X(g0 h3 e1 b2) e=X(c2 d2 h2 f0) f=X(e3 i0 g1 c3) g=X(d0 f2 i3 h0) h=X(g3 i2 e2 d1) i=X(f1 j0 h1 g2) j=V(i1)
a=V(b3) b=X(c3 c2 d3 a0) c=X(d2 e3 b1 b0) d=X(f3 e0 c0 b2) e=X(d1 f2 g3 c1) f=X(h3 g0 e1 d0) g=X(f1 i3 h0 e2) h=X(g2 i2 i0 f0) i=X(h2 j0 h1 g1) j=V(i1)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e3 f0 b1 b0) d=X(b2 g0 h3 e0) e=X(d3 h2 g1 c0) f=V(c1) g=X(d1 e2 i3 i2) h=X(i1 i0 e1 d2) i=X(h1 h0 g3 g2)
a=V(b0) b=X(a0 c3 d3 c0) c=X(b3 d2 e3 b1) d=X(f3 e0 c1 b2) e=X(d1 g0 g3 c2) f=X(g2 h0 g1 d0) g=X(e1 f2 f0 e2) h=V(f1)
a=V(b0) b=X(a0 c0 d3 d2) c=X(b1 e3 f3 g3) d=X(g2 h0 b3 b2) e=X(h3 i3 f0 c1) f=X(e2 i2 g0 c2) g=X(f2 h1 d0 c3) h=X(d1 g1 i0 e0) i=X(h2 j0 f1 e1) j=V(i1)
a=V(b0) b=X(a0 c3 d3 c0) c=X(b3 e3 f3 b1) d=X(f2 g3 e0 b2) e=X(d2 h3 i3 c1) f=X(i2 g0 d0 c2) g=X(f1 i1 h0 d1) h=X(g2 j0 i0 e1) i=X(h2 g1 f0 e2) j=V(h1)
a=V(b3) b=X(c3 c2 d0 a0) c=X(e3 f0 b1 b0) d=X(b2 g0 h0 e0) e=X(d3 i3 f1 c0) f=X(c1 e2 i2 g1) g=X(d1 f3 i1 h2) h=X(d2 j0 g3 i0) i=X(h3 g2 f2 e1) j=V(h1)
a=V(b0) b=X(a0 c0 c3 d3) c=X(b1 e0 d0 b2) d=X(c2 f3 e1 b3) e=X(c1 d2 f2 g3) f=X(h0 g0 e2 d1) g=X(f1 i3 h1 e3) h=X(f0 g2 i1 i0) i=X(h3 h2 j0 g1) j=V(i2)
a=V(b0) b=X(a0 c0 d3 c1) c=X(b1 b3 d2 e0) d=X(e3 f3 c2 b2) e=X(c3 g3 f0 d0) f=X(e2 h0 h3 d1) g=X(i0 h2 h1 e1) h=X(f1 g2 g1 f2) i=V(g0)
a=V(b0) b=X(a0 c0 d0 e3) c=X(b1 e2 f3 d1) d=X(b2 c3 f2 g0) e=X(f1 f0 c1 b3) f=X(e1 e0 d2 c2) g=V(d3)
"""
knotoids = [line.strip() for line in raw.strip().splitlines() if line.strip()]

def NOTtest_knotoids():
    import knotpy as kp

    kp.settings.allowed_moves = "r1,r2,r3"

    for k in kp.bar(knotoids):
        k = kp.from_knotpy_notation(k)
        i = [
            kp.kauffman_bracket_skein_module(k, normalize=True)[0][0],
            kp.affine_index_polynomial(k),
            kp.arrow_polynomial(k),
            kp.mock_alexander_polynomial(k),
            kp.yamada(kp.closure(k, True, True))
        ]

        moves = kp.choose_random_reidemeister_moves(k)
        for move in moves:
            k_ = kp.make_reidemeister_move(k, move)
            i_ = [
                kp.kauffman_bracket_skein_module(k_, normalize=True)[0][0],
                kp.affine_index_polynomial(k_),
                kp.arrow_polynomial(k_),
                kp.mock_alexander_polynomial(k_),
                kp.yamada(kp.closure(k, True, True))
            ]

            if i_ != i:
                for q, q_, s in zip(i, i_, ["kbsm", "affine", "arrow", "mock", "yamada"]):
                    if q != q_:
                        print(k)
                        print(k_)
                        print(f"{s}: {q} != {q_} ({move})")
            else:
                print("ok.")


# if __name__ == "__main__":
#     print("v2")
#     test_knotoids()
